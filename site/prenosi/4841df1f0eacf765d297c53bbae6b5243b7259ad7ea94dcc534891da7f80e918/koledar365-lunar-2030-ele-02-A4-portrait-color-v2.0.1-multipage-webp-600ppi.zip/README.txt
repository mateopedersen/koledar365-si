Koledar365 · koledar365.si

Za tisk izberite PDF in merilo 100 % oziroma dejansko velikost. Slike WebP so pripravljene za navedeno velikost papirja pri 600 ppi.

24 strani. Vse slike so izrisane iz priloženega PDF-ja. Vrstni red: p001, p002 …
Barvni prostor: sRGB. Pisave v PDF-ju so vdelane.
Kontrolne vsote, velikost papirja in slik: manifest.json.
Osebni vnosi so vključeni v celotnem seznamu. Znak … v kratkem pregledu napoti na ta seznam.
